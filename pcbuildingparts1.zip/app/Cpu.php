<?php

  

namespace App;

   

use Illuminate\Database\Eloquent\Model;

  

class Cpu extends Model

{

     public $fillable = ['id','name'];  

}