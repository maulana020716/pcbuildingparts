<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use App\Blog;

class Blog1Controller extends Controller
{
    public function index()
    {
    	$blogs = DB::table('blogs')->orderBy('id', 'DESC')->paginate(3);
    	return view('welcome',[
    		'blogs' => $blogs
    	]);
    }

}
