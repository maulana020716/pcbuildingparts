<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Blog;
use Validator,Redirect,Response,File;
use Illuminate\Support\Facades\Input;
use Carbon\Carbon;

class BlogController extends Controller
{
    public function index()
    {
    	$blogs = Blog::get();
    	return view('post.post_textarea',[
    		'blogs' => $blogs
    	]);
    }

    public function store(Request $request)
    {
    	$blog = new Blog;
        $blog->name = $request->name;
        $blog->message = $request->message;
        if($request->hasFile('thumbnail')) {

            $file = Input::file('thumbnail');
            //getting timestamp
            $timestamp = str_replace([' ', ':'], '-', Carbon::now()->toDateTimeString());
            $name = $timestamp. '-' .$file->getClientOriginalName();
            $file->move(public_path().'/images/', $name);
            $blog->thumbnail = url('/images/' . $name);

        }
$blog->save();
    	return redirect()->back();
    }

    public function getFullPost($blog_id) {
    $blogs = Blog::where('id', '=', $blog_id)->get();
    return view('post.read')->with(compact('blogs'));
    }


    public function createPost(Request $request){
        if($request->hasFile('image')){
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            Image::make($image)->resize(300,300)->save(public_path('uploads/image' . $filename));
            $post = Auth::user();
            $post->image = $filename;
            $post->save();
            $post = Post::create(array(
            'title' => Input::get('title'),
            'description' => Input::get('description'),
            'author' => Auth::user()->id
        
        ));

        }    
        return redirect()->route('home', array('post' =>  Auth::user()))->with('success', 'Post has been successfully added!');
    }

}
