<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    public function getIndex() {
        $posts = DB::table('users')->leftjoin('posts', 'users.id', '=', 'posts.author')->paginate(1);
        $archives = DB::table('posts')->orderBy('id', 'DESC')->get();

        $data = array(
            'posts' => $posts,
            'archives' => $archives
        );
        return view('welcome', $data);
    }

    public function getFullPost($blog_id) {
        $blogs = DB::table('blogs')->where('blogs.id', '=', $blog_id)->first();
        $blogs = array(
            'name' => $name,
            'message' => $message
        );
        return view('welcome', ['blogs' => $blogs]);
    }
}