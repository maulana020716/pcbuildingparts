<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use App\Blog;

class ReviewController extends Controller
{
    public function index()
    {
    	$blogs = DB::table('blogs')->orderBy('id', 'DESC')->paginate(3);
    	return view('review',[
    		'blogs' => $blogs
    	]);
    }
        
    public function indexpost(Request $request)
    {
    	if($request->hasFile('thumbnail')){
            $thumbnail = $request->file('thumbnail');
            $filename = time() . '.' . $thumbnail->getClientOriginalExtension();
            Image::make($thumbnail)->resize(850,350)->save(public_path('image/avatars' . $filename));
            $blogs->thumbnail = $filename;
            $blogs->save();
        }
        return view('review',[
    		'blogs' => $blogs,
    		'thumbnail' => $thumbnail,
    		'filename' => $filename
    	]);
    }

}