<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Password Setidaknya Harus Terdiri Dari 6 Karakter!.',
    'reset' => 'Password Anda Telah Diubah!',
    'sent' => 'Kita Telah Mengirim Link Email Password Anda Yang Di Reset!',
    'token' => 'Token Password Ini Tidak Valid.',
    'user' => "Kamu Tidak Dapat Menemukan User Dengan Email Tersebut.",

];
