@extends('layouts.master')

@section('content')

    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Masuk</h2>
            <div class="site-breadcrumb">
                <a href="">Akun</a>  /
                <span>Masuk</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->

    <!-- login section -->

    <section class="newsletter-section">
        <div class="container">
            <h2>Masukan Biodata Anda</h2>
                <form class="newsletter-form" method="POST" action="{{ route('login') }}">
                    {{ csrf_field() }}
                        <center>
                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <input id="email" type="email" placeholder="MASUKAN E-MAIl"  name="email" value="{{ old('email') }}" required autofocus>
                                    @if ($errors->has('email'))
                                    <br>
                                        <span class="help-block" style="color: #ffffff">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                            </div>          
                        </center>
                        <br>
                        <center>
                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <input id="password" type="password" placeholder="MASUKAN PASSWORD"  name="password" required>
                                    @if ($errors->has('password'))
                                    <br>
                                        <span class="help-block" style="color: #ffffff">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                            </div>
                        </center>
                <br>
                <center>
                    <a style="color: white">Belum Punya Akun ?</a>
                    <a style="color: white" class="btn btn-link" href="{{ url('/register') }}">Daftar</a>
                </center>
                <center>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <button type="submit" class="site-btn">
                                MASUK  <img src="asset/img/icons/double-arrow.png">
                            </button>                                
                        </div>
                    </div>
                </center>
                </form>
        </div>
    </section>

<!-- login end-->


@endsection