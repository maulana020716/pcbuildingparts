@extends('layouts.master')
@section('content')
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Buat Rakitan Baru</h2>
            <div class="site-breadcrumb">
                <a href="">Rakitan</a>  /
                <span>Buat Rakitan Baru</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
<!DOCTYPE html>
<html>
 <head>
  <title>Ajax Autocomplete Textbox in Laravel using JQuery</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <section class="contact-page">
        <div class="container">
          <form method="POST" action="">
            <div class="col-md-6 form-group">
            	<h3 style="color: white">CPU :</h3>
            	<input type="text" name="namecpu" id="namecpu" class="form-control input-lg" placeholder="Masukan Tipe CPU" />
            		<div id="cpuList"></div>
            	<h3 style="color: white">VGA :</h3>
              <input type="text" name="namevga" id="namevga" class="form-control input-lg" placeholder="Masukan Tipe VGA" />
                <div id="vgaList"></div>
                <h3 style="color: white">Motherboard :</h3>
              <input type="text" name="namemtb" id="namemtb" class="form-control input-lg" placeholder="Masukan Tipe Motherboard" />
                <div id="mtbList"></div>
                <h3 style="color: white">Storage :</h3>
              <input type="text" name="namesto" id="namesto" class="form-control input-lg" placeholder="Masukan Tipe Storage" />
                <div id="stoList"></div>
                <h3 style="color: white">Memory :</h3>
              <input type="text" name="namemem" id="namemem" class="form-control input-lg" placeholder="Masukan Tipe Memory" />
                <div id="memList"></div>
              <br>
          </form> 
              <button class="pull-center site-btn"><a href="{{ url('/autocomplete1') }}">CEK KOMPATIBILITAS</a><img src="asset/img/icons/double-arrow.png" alt=""/></button>
            </div>
          
   			{{ csrf_field() }}
   		</div>
   	</section>


<script>
$(document).ready(function(){

 $('#namecpu').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchcpu') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#cpuList').fadeIn();  
                    $('#cpuList').html(data);
          }
         });
        }
    });

$('#namevga').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchvga') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#vgaList').fadeIn();  
                    $('#vgaList').html(data);
          }
         });
        }
    });

$('#namemtb').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchmtb') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#mtbList').fadeIn();  
                    $('#mtbList').html(data);
          }
         });
        }
    });

$('#namesto').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchsto') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#stoList').fadeIn();  
                    $('#stoList').html(data);
          }
         });
        }
    });

$('#namemem').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchmem') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#memList').fadeIn();  
                    $('#memList').html(data);
          }
         });
        }
    });


  $(document).on('click', '#cpuList li', function(){  
        $('#namecpu').val($(this).text());  
        $('#cpuList').fadeOut();  
    });  

  $(document).on('click', '#vgaList li', function(){  
        $('#namevga').val($(this).text());  
        $('#vgaList').fadeOut();   
    });  

  $(document).on('click', '#mtbList li', function(){  
        $('#namemtb').val($(this).text());  
        $('#mtbList').fadeOut();   
    }); 

    $(document).on('click', '#stoList li', function(){  
        $('#namesto').val($(this).text());  
        $('#stoList').fadeOut();  
    });   

    $(document).on('click', '#memList li', function(){  
        $('#namemem').val($(this).text());  
        $('#memList').fadeOut();  
    });   
});
</script>

@endsection

