@extends('layouts.master')
@section('content')
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Buat Rakitan Baru</h2>
            <div class="site-breadcrumb">
                <a href="">Rakitan</a>  /
                <span>Buat Rakitan Baru</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
<!DOCTYPE html>
<html>
 <head>
  <title>Ajax Autocomplete Textbox in Laravel using JQuery</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <section class="contact-page">
        <div class="container">
          <div class="alert alert-danger" role="alert">
            MAAF SEPERTINYA ADA BEBERAPA PERANGKAT ANDA YANG TIDAK KOMPATIBEL
          </div>
          <div class="alert alert-danger" role="alert">
            SILAHKAN CEK HARDWARE ANDA YANG BERMASALAH
          </div>
          <form method="POST" action="">
            <div class="col-md-4 form-group">      
            	<label style="color: white">CPU :</label>
            	<input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="Intel Atom D2500" />
            		<div id="cpuList"></div>           
            </div>
            <div class="col-md-4 form-group">
              <label style="color: white">Harga :</label>
              <input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="800000"/>
            </div>
            <div class="col-md-4 form-group">
              <br>
            <div class="alert alert-danger" role="alert">
            HARDWARE MEMILIKI SOCKET FCBGA5590
            </div>
            </div>
            <div class="col-md-4 form-group">
            	<label style="color: white">VGA :</label>
              <input type="text" name="namevga" id="namevga" class="form-control input-lg" value="MSI GTX 1060 AERO ITX 6G OC" />
                <div id="vgaList"></div>
            </div>
            <div class="col-md-4 form-group">
              <label style="color: white">Harga :</label>
              <input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="4470000"/>
            </div>
            <div class="col-md-4 form-group">
              <br>
              <h3><a style="color: white" href="https://www.amazon.com/MSI-GTX-1060-ITX-AERO/dp/B06XBGGTVG/ref=sr_1_1?keywords=MSI+GTX+1060+AERO+ITX+6G+OC&qid=1562899432&s=gateway&sr=8-1">Beli</a></h3>
              <br>
            </div>
            <div class="col-md-4 form-group">
                <label style="color: white">Motherboard :</label>
              <input type="text" name="namemtb" id="namemtb" class="form-control input-lg" value="ASRock B150M-HDS" />
                <div id="mtbList"></div>
            </div>
            <div class="col-md-4 form-group">
              <label style="color: white">Harga :</label>
              <input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="1240000"/>
            </div>
            <div class="col-md-4 form-group">
              <br>
            <div class="alert alert-danger" role="alert">
            HARDWARE MEMILIKI SOCKET LGA 1151
            </div>
            </div>
            <div class="col-md-4 form-group">
                <label style="color: white">Storage :</label>
              <input type="text" name="namesto" id="namesto" class="form-control input-lg" value="Samsung 850 EVO-Series" />
                <div id="stoList"></div>
            </div>
            <div class="col-md-4 form-group">
              <label style="color: white">Harga :</label>
              <input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="1375000"/>
            </div>
            <div class="col-md-4 form-group">
              <br>
              <h3><a style="color: white" href="https://www.amazon.com/Samsung-2-5-Inch-Internal-MZ-75E500B-AM/dp/B00OBRE5UE/ref=sr_1_1?keywords=Samsung+850+EVO-Series&qid=1562899550&s=gateway&sr=8-1">Beli</a></h3>
              <br>
            </div>
            <div class="col-md-4 form-group">              
                <label style="color: white">Memory :</label>
              <input type="text" name="namemem" id="namemem" class="form-control input-lg" value="G.Skill F2-6400CL6Q-16GBMQ 16 GB" />
                <div id="memList"></div>
            </div>
            <div class="col-md-4 form-group">
              <label style="color: white">Harga :</label>
              <input type="text" name="namecpu" id="namecpu" class="form-control input-lg" value="818000"/>
            </div>
            <div class="col-md-4 form-group">
              <br>
              <h3><a style="color: white" href="https://www.amazon.com/G-Skill-Ripjaws-PC4-25600-3200MHz-F4-3200C16D-16GVKB/dp/B015FXXBW0/ref=sr_1_fkmr0_1?keywords=G.Skill+F2-6400CL6Q-16GBMQ+16+GB&qid=1562899581&s=gateway&sr=8-1-fkmr0">Beli</a></h3>
              <br>
            </div>
            <button class="pull-center site-btn"><a href="{{ url('/autocomplete') }}">RAKIT DENGAN PERANGKAT LAIN</a><img src="asset/img/icons/double-arrow.png" alt=""/></button>
          </form> 
   			{{ csrf_field() }}
   		</div>
   	</section>


<script>
$(document).ready(function(){

 $('#namecpu').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchcpu') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#cpuList').fadeIn();  
                    $('#cpuList').html(data);
          }
         });
        }
    });

$('#namevga').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchvga') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#vgaList').fadeIn();  
                    $('#vgaList').html(data);
          }
         });
        }
    });

$('#namemtb').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchmtb') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#mtbList').fadeIn();  
                    $('#mtbList').html(data);
          }
         });
        }
    });

$('#namesto').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchsto') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#stoList').fadeIn();  
                    $('#stoList').html(data);
          }
         });
        }
    });

$('#namemem').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"{{ route('autocomplete.fetchmem') }}",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#memList').fadeIn();  
                    $('#memList').html(data);
          }
         });
        }
    });


  $(document).on('click', '#cpuList li', function(){  
        $('#namecpu').val($(this).text());  
        $('#cpuList').fadeOut();  
    });  

  $(document).on('click', '#vgaList li', function(){  
        $('#namevga').val($(this).text());  
        $('#vgaList').fadeOut();   
    });  

  $(document).on('click', '#mtbList li', function(){  
        $('#namemtb').val($(this).text());  
        $('#mtbList').fadeOut();   
    }); 

    $(document).on('click', '#stoList li', function(){  
        $('#namesto').val($(this).text());  
        $('#stoList').fadeOut();  
    });   

    $(document).on('click', '#memList li', function(){  
        $('#namemem').val($(this).text());  
        $('#memList').fadeOut();  
    });   
});
</script>

@endsection

