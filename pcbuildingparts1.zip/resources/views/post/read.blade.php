@extends('layouts.masterblog')

@section('content')

<!-- Games section -->
    <section class="games-single-page">
        <div class="container">
            <div class="row">
                <div class="col-xl-9 col-lg-8 col-md-7 game-single-content">
                    @foreach ($blogs as $blog)
                    <div class="gs-meta">{{ Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')  }} /  di <a href="">Games</a></div>
                    <h2 class="gs-title">{{ $blog->name }}</h2>
                    <p>{!! $blog->message !!}</p>
                    @endforeach
                </div>
                <div class="col-xl-3 col-lg-4 col-md-5 sidebar game-page-sideber">
                    <div id="stickySidebar">
                        <div class="widget-item">
                            <div class="rating-widget">
                                <h4 class="widget-title">Penilaian</h4>
                                <ul>
                                    <li>Harga<span>3.5/5</span></li>
                                    <li>Grafis<span>4.5/5</span></li>
                                    <li>Level<span>3.5/5</span></li>
                                    <li>Tingkat Kesulitan<span>4.5/5</span></li>
                                </ul>
                                <div class="rating">
                                    <h5><i>Rating</i><span>4.5</span> / 5</h5>
                                </div>
                            </div>
                        </div>
                        <div class="widget-item">
                            <div class="testimonials-widget">
                                <h4 class="widget-title">Quotes</h4>
                                <div class="testim-text">
                                    <p>Mana yang lebih baik ?, untuk terlahir dengan kebaikan, atau melawan sifat burukmu dengan kemauan yang keras ?</p>
                                    <h6><span>Paathurnax,</span>Skyrim</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- Games end-->
@endsection