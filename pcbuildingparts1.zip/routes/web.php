<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();Route::get('/home', 'HomeController@index')    
    ->name('home');Route::get('/admin', 'AdminController@admin')    
    ->middleware('is_admin')    
    ->name('admin');
    Route::get('/posting','BlogController@index')->name('blog');
	Route::post('/posting','BlogController@store')->name('blog.store');
	Route::post('/profile','BlogController@thumbnail')->name('blog.thumb');
	Route::get('/','Blog1Controller@index')->name('blog');
	Route::get('/review','ReviewController@index');





Route::post('/submit', 'HomeController@posting')->name('submit');

Route::get('search', 'SearchController@index')->name('search');

Route::get('/autocomplete','AutocompleteController@index');
Route::post('/autocomplete/fetchcpu','AutocompleteController@fetchcpu')->name('autocomplete.fetchcpu');
Route::post('/autocomplete/fetchvga','AutocompleteController@fetchvga')->name('autocomplete.fetchvga');
Route::post('/autocomplete/fetchmtb','AutocompleteController@fetchmtb')->name('autocomplete.fetchmtb');
Route::post('/autocomplete/fetchsto','AutocompleteController@fetchsto')->name('autocomplete.fetchsto');
Route::post('/autocomplete/fetchmem','AutocompleteController@fetchmem')->name('autocomplete.fetchmem');
Route::get('/autocomplete1',function () {
    return view('autocomplete1');});
Route::get('/autocomplete2',function () {
    return view('autocomplete2');});
Route::post('/autocomplete2/fetchcpu','AutocompleteController@fetchcpu')->name('autocomplete2.fetchcpu');
Route::post('/autocomplete2/fetchvga','AutocompleteController@fetchvga')->name('autocomplete2.fetchvga');
Route::post('/autocomplete2/fetchmtb','AutocompleteController@fetchmtb')->name('autocomplete2.fetchmtb');
Route::post('/autocomplete2/fetchsto','AutocompleteController@fetchsto')->name('autocomplete2.fetchsto');
Route::post('/autocomplete2/fetchmem','AutocompleteController@fetchmem')->name('autocomplete2.fetchmem');
Route::get('/autocomplete3',function () {
    return view('autocomplete3');});
Route::get('/about',function () {
    return view('about');});
Route::get('/spek',function () {
    return view('spek');});

Route::get('/2019', 'BlogController@blog');
Auth::routes();
Route::get('/profile','HomeController@profile');
Route::post('/profile','HomeController@update_avatar');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/author/post','HomeController@getPostForm')->name('post.form');
Route::post('/author/post', 'HomeController@createPost')->name('post.form');
Route::get('/author/post/detail/{id}', 'HomeController@getPost')->name('post.detail');
Route::get('/author/post/edit/{id}', 'HomeController@editPost')->name('post.edit');
Route::post('/author/post/edit/{id}', 'HomeController@updatePost')->name('post.update');
Route::get('/author/post/delete/{id}', 'HomeController@deletePost')->name('post.delete');
Route::get('/post/read/{blog_id}', 'BlogController@getFullPost')->name('post.read');

