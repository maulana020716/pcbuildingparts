

<?php $__env->startSection('content'); ?>
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Kontak</h2>
            <div class="site-breadcrumb">
                <a href="">Tentang</a>  /
                <span>Kontak</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
    <!-- Contact page -->
    <section class="contact-page">
        <div class="container">
            <div class="map"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d495.8291669214647!2d107.01506414815984!3d-6.179808429152282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sid!4v1561394660513!5m2!1sen!2sid" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
            <div class="row">
                <div class="col-lg-7 order-2 order-lg-1">
                    <form class="contact-form">
                        <input type="text" placeholder="Nama Anda">
                        <input type="text" placeholder="Email Anda">
                        <input type="text" placeholder="Subjek">
                        <textarea placeholder="Pesan"></textarea>
                        <button class="site-btn">Kirim Saran<img src="asset/img/icons/double-arrow.png" alt="#"/></button>
                    </form>
                </div>
                <div class="col-lg-5 order-1 order-lg-2 contact-text text-white">
                    <h3>Tentang</h3>
                    <p>PCBuildingParts adalah salah satu website penyedia simulasi kompatibilitas hardware personal komputer, Website ini dibuat dengan tujuan untuk membantu para pengguna dalam hal merakit komputer agar tidak keliru dalam memilih bagian-bagian komputer sehingga komputer dapat digunakan dengan performa yang maksimal</p>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/location.png" alt=""></div>
                        <div class="ci-text">Blok O21 No 3 Babelan,Bekasi</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/phone.png" alt=""></div>
                        <div class="ci-text">085778779273</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/mail.png" alt=""></div>
                        <div class="ci-text">maulana020716@gmail.com</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact page end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>