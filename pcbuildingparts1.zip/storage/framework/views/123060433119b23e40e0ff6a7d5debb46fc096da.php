<?php $__env->startSection('content'); ?>
    <!-- Hero section -->
    <section class="hero-section overflow-hidden">
        <div class="hero-slider owl-carousel">
            <div class="hero-item set-bg d-flex align-items-center justify-content-center text-center" data-setbg="asset/img/slider-bg-1.jpg">
                <div class="container">
                    <h2>Rakit PC anda Sekarang !</h2>
                    <p class="text-white">Rakit Komputer anda Sekarang dengan memilih part-part yang anda inginkan,<br>Kami akan membantu anda untuk masalah kompatibilitas.</p>
                    <?php if(Route::has('login')): ?>
                    <?php if(Auth::check()): ?>
                    <a href="<?php echo e(url('/autocomplete')); ?>" class="site-btn">Rakit...  <img srcset="asset/img/icons/double-arrow.png" alt="#" /></a>
                    <?php else: ?>
                    <a href="<?php echo e(url('/login')); ?>" class="site-btn">Rakit...  <img srcset="asset/img/icons/double-arrow.png" alt="#" /></a>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="hero-item set-bg d-flex align-items-center justify-content-center text-center" data-setbg="asset/img/slider-bg-2.jpg">
                <div class="container">
                    <h2>Ikuti Ulasan Kami!</h2>
                    <p class="text-white">Simak ulasan kami dalam dalam beberapa game dalam platform pc yang baru rilis,<br>kirimkan juga pendapat kalian dari ulasan kami.</p>
                    <a href="<?php echo e(url('/review')); ?>" class="site-btn">Simak...  <img src="asset/img/icons/double-arrow.png" alt="#"/></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero section end-->

    <!-- Intro section -->
    <section class="intro-section">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="intro-text-box text-box text-white">                     
                        <div class="top-meta"><?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?> /  di <a href="">Rakitan</a></div>
                        <h3><?php echo e($blog->name); ?></h3>
                        <p><?php echo \Illuminate\Support\Str::words($blog->message, 30, '...'); ?></p>
                        <a href="<?php echo e(route('post.read', ['blog_id' => $blog->id])); ?>" class="read-more">Lanjutkan Baca  <img src="asset/img/icons/double-arrow.png" alt="<?php echo e(url('/2019')); ?>"/></a>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Intro section end -->
    <!-- Blog section -->
    <section class="blog-section spad">
        <div class="container">
            <div class="row">
                <div class="col-xl-9 col-lg-8 col-md-7">
                    <div class="section-title text-white">
                        <h2>Berita Terbaru</h2>
                    </div>
                    <ul class="blog-filter">
                        <li><a href="#">VGA</a></li>
                        <li><a href="#">PC GAMES</a></li>
                        <li><a href="#">CPU</a></li>
                        <li><a href="#">MOTHERBOARD</a></li>
                    </ul>
                    <!-- Blog item -->
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-item">
                        <div class="blog-thumb">
                            <img style="width: 350px; height: 350px;" src="<?php echo e($blog->thumbnail); ?>" alt="" >
                        </div>

                        <div class="blog-text text-box text-white">
                            
                            <div class="top-meta"><?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?> /  di <a href="">Rakitan</a></div>
                            <h3><?php echo e($blog->name); ?></h3>
                            <p><?php echo \Illuminate\Support\Str::words($blog->message, 30, '...'); ?></p>
                            <a href="<?php echo e(route('post.read', ['blog_id' => $blog->id])); ?>" class="read-more">Lanjutkan Baca  <img src="asset/img/icons/double-arrow.png" alt="#"/></a>
                            
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-5 sidebar">
                    <div id="stickySidebar">
                        <div class="widget-item">
                            <h4 class="widget-title">Trending</h4>
                            <div class="trending-widget">
                                <div class="tw-item">
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tw-thumb">
                                        <img style="width: 90px; height: 90px;" src="<?php echo e($blog->thumbnail); ?>" alt="" >
                                    </div>
                                    <div class="tw-text">
                                        <div class="tw-meta"><?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?> /  di <a href="">Rakitan</a></div>
                                        <a style="color: white" href="<?php echo e(route('post.read', ['blog_id' => $blog->id])); ?>"><?php echo e($blog->name); ?></a>
                                    </div>
                                    <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="widget-item">
                            <div class="categories-widget">
                                <h4 class="widget-title">Kategori</h4>
                                <ul>
                                    <li><a href="">Games</a></li>
                                    <li><a href="">Tips dan Trik Game</a></li>
                                    <li><a href="">Game Online</a></li>
                                    <li><a href="">Team Games</a></li>
                                    <li><a href="">Komunitas</a></li>
                                    <li><a href="">Tanpa Kategori</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="widget-item">
                        <a href="#" class="add">
                            <img src="asset/img/add.jpg" alt="">
                        </a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog section end -->
           <!-- Intro section -->
    <section class="intro-video-section set-bg d-flex align-items-end " data-setbg="asset/img/promo-bg.jpg">
        <a href="https://www.youtube.com/watch?v=IhX0fOUYd8Q" class="video-play-btn video-popup"><img src="asset/img/icons/solid-right-arrow.png" alt="#"/></a>
        <div class="container">
            <div class="video-text">
                <h2>CARA MERAKIT PC ! Step-by-step</h2>
                <p class="text-white">Video tentang cara perakitan PC secara step by step dari Channel Youtube Bitwit untuk pemula yang masih kebingungan dalam merakit PC</p>
            </div>
        </div>
    </section>
    <!-- Intro section end -->


    <!-- Featured section -->
    <section class="featured-section">
        <div class="featured-bg set-bg" data-setbg="asset/img/featured-bg.jpg"></div>
        <div class="featured-box">
            <div class="text-box">
                <div class="top-meta">11.11.18  /  in <a href="">Games</a></div>
                <h3>Jadwal Lengkap Konferensi Pers E3 2019</h3>
                <p>Menjadi ajang tahunan terbesar yang ditunggu-tunggu dan sangat diminati para gamer, Electronic Entertainment Expo (E3) tahun ini nampaknya siap membawa industri video game ke jenjang berikutnya dan menghadirkan rangkaian acara yang lebih meriah daripada tahun sebelumnya.E3 2019 yang akan dilaksanakan di Los Angeles ini rencananya akan  dimulai pada tanggal 10 Juni mendatang. Terdapat 11 konferensi pers atau presentasi utama dari developer, publisher, maupun pelaku-pelaku industri video game lainnya. Berikut jadwal lengkap konferensi pers E3 2019....</p>
                <a href="#" class="read-more">Lanjutkan Baca  <img src="asset/img/icons/double-arrow.png" alt="#"/></a>
            </div>
        </div>
    </section>
    <!-- Featured section end-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>