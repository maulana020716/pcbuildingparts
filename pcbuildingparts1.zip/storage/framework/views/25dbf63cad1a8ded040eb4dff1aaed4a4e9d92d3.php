
<?php $__env->startSection('content'); ?>
	<!-- Page top section -->
	<section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/3.jpg">
		<div class="page-info">
			<h2>Blog</h2>
			<div class="site-breadcrumb">
				<a href="">Home</a>  /
				<span>Blog</span>
			</div>
		</div>
	</section>
	<!-- Page top end-->


	<!-- Blog page -->
	<section class="blog-page">
		<div class="container">
			<div class="row">
				<div class="col-xl-9 col-lg-8 col-md-7">
					<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="big-blog-item">
						<img style="width: 1000px; height: 300px;" src="<?php echo e($blog->thumbnail); ?>" alt="" >
						<div class="blog-content text-box text-white">
							<div class="top-meta"><?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?> /  di <a href="">Games</a></div>
							<h3><?php echo e($blog->name); ?></h3>
							<p><?php echo \Illuminate\Support\Str::words($blog->message, 45, '...'); ?></p>
							<a href="<?php echo e(route('post.read', ['blog_id' => $blog->id])); ?>" class="read-more">Lanjutkan Baca <img src="asset/img/icons/double-arrow.png" alt="#"/></a>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="site-pagination">
						<a href="#" class="active">01.</a>
						<a href="#">02.</a>
						<a href="#">03.</a>
					</div>
				</div>
				<div class="col-xl-3 col-lg-4 col-md-5 sidebar">
					<div id="stickySidebar">
						<div class="widget-item">
                            <h4 class="widget-title">Trending</h4>
                            <div class="trending-widget">
                                <div class="tw-item">
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tw-thumb">
                                        <img style="width: 90px; height: 90px;" src="<?php echo e($blog->thumbnail); ?>" alt="" >
                                    </div>
                                    <div class="tw-text">
                                        <div class="tw-meta"><?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?> /  di <a href="">Rakitan</a></div>
                                        <a style="color: white" href="<?php echo e(route('post.read', ['blog_id' => $blog->id])); ?>"><?php echo e($blog->name); ?></a>
                                    </div>
                                    <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
						<div class="widget-item">
							<div class="categories-widget">
								<h4 class="widget-title">KATEGORI</h4>
								<ul>
									<li><a href="">Games</a></li>
									<li><a href="">Gaming Tips & Tricks</a></li>
									<li><a href="">Online Games</a></li>
									<li><a href="">Team Games</a></li>
									<li><a href="">Komunitas</a></li>
									<li><a href="">Tidak Terkategori</a></li>
								</ul>
							</div>
						</div>					
						<div class="widget-item">
							<a href="#" class="add">
								<img src="asset/img/add.jpg" alt="">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Blog page end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>