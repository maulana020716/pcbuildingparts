
<?php $__env->startSection('content'); ?>
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Tambah Konten</h2>
            <div class="site-breadcrumb">
                <a href="">Konten</a>  /
                <span>Tambah Konten</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
    <section class="games-single-page">
        <div class="container">
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <h4 style="color: black;" >Judul</h4>
                            <br>
                            <input type="text" class="form-control" name="name">
                        </div> 
                        <div class="form-group">
                            <h4 style="color: black;" >Thumbnail</h4>
                            <br>
                            <input type="file" name="thumbnail">
                        </div>                     
                        <div class="form-group">
                            <h4 style="color: black;" >Isi</h4>
                            <br>
                                <textarea class="form-control" name="message" id="" rows="10"></textarea>
                        </div>
                        <div class="form-group">
                            <button class="pull-right site-btn" type="submit" >Upload<img src="asset/img/icons/double-arrow.png" alt="#"/></button>
                        </div>                     
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>