

<?php $__env->startSection('content'); ?>
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Spesifikasi Sistem</h2>
            <div class="site-breadcrumb">
                <a href="">Tentang</a>  /
                <span>Spesifikasi Sistem</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
    <!-- Contact page -->
    <section class="contact-page">
        <div class="container">
            
            <div class="row">
                <div class="col-lg-7 order-2 order-lg-1">
                    <<div><img src="asset/img/img1.png"></div>
                </div>
                <div class="col-lg-5 order-1 order-lg-2 contact-text text-white">
                    <h3>Spesifikasi</h3>
                    <p>PCBuildingParts adalah salah satu website penyedia simulasi kompatibilitas hardware personal komputer, Website ini dibuat dengan framework laravel dan bahasa pemrograman Php serta perangkat lunak pengembang website lain diantaranya :</p>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">Laravel 5.4</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">PHP 5.6.28</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">HTML</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">CSS</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">Javascript</div>
                    </div>
                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">Bootstrap 4</div>
                    </div>

                    <div class="cont-info">
                        <div class="ci-icon"><img src="asset/img/icons/double-arrow.png" alt="#"/></div>
                        <div class="ci-text">MySQL</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact page end-->

<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>