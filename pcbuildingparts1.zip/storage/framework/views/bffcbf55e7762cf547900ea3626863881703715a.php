<?php $__env->startSection('content'); ?>

    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Daftar</h2>
            <div class="site-breadcrumb">
                <a href="">Akun</a>  /
                <span>Daftar</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->


    <!-- register section -->
    <section class="newsletter-section">
            <div class="container">
                <h2>Masukan Biodata Anda</h2>
                    <form class="newsletter-form" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <center>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <input id="name" type="text" placeholder="MASUKAN NAMA ANDA" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                <br>
                                    <span class="help-block" style="color: #ffffff">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        </center>
                        <br>
                        <center>    
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <input id="email" type="email" placeholder="MASUKAN EMAIL ANDA"name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                <br>
                                    <span class="help-block" style="color: #ffffff">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        </center>
                        <br>
                        <center>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <input id="password" type="password" placeholder="MASUKAN PASSWORD ANDA"name="password" required>
                                <?php if($errors->has('password')): ?>
                                <br>
                                    <span class="help-block" style="color: #ffffff">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        </center>
                        <br>
                        <center>
                        <div class="form-group">
                                <input id="password-confirm" type="password" placeholder="MASUKAN LAGI PASSWORD ANDA"name="password_confirmation" required>
                            </div>
                        </div>
                        </center>
                        <br>
                        <center>
                        <div class="form-group">
                                <button type="submit" class="site-btn">
                                    Daftar <img src="asset/img/icons/double-arrow.png">
                                </button>
                            </div>
                        </div>
                        </center>
                    </form>
            </div>
    </section>

    <!-- register end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>