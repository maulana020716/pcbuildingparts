


<?php $__env->startSection('content'); ?>
    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="asset/img/page-top-bg/2.jpg">
        <div class="page-info">
            <h2>Profil</h2>
            <div class="site-breadcrumb">
                <a href="">Akun</a>  /
                <span>Profil</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
    <!-- Profile Section-->

    <section class="games-single-page">
        <div class="container">
            <img src="uploads/avatars<?php echo e($user->avatar); ?>" style="width: 150px; height: 150px; float:left; border-radius: 50%; margin-right: 25px;">
            <h3 style="color: #ffffff">Profil <?php echo e($user->name); ?></h3>
            <form enctype="multipart/form-data" action="profile" method="POST">
                <label style="color: #ffffff">Update Foto Saya</label>
                <br>
                <input type="file" name="avatar" style="color: #ffffff">
                <br>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" style="color: #ffffff">
                <button class="pull-right site-btn" type="submit">Upload<img src="asset/img/icons/double-arrow.png" alt="#"/></button>
            </form>
            <br>
            <br>
            <br>
            <br>
        </div>
    </section>

    <!-- Profile Section End-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>