<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>PCBuildingParts</title>
    <meta charset="UTF-8">
    <meta name="description" content="PCBuildingParts">
    <meta name="keywords" content="endGam,gGaming, magazine, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link href="../../asset/img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i" rel="stylesheet">


    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../asset/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../../asset/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="../../asset/css/slicknav.min.css"/>
    <link rel="stylesheet" href="../../asset/css/owl.carousel.min.css"/>
    <link rel="stylesheet" href="../../asset/css/magnific-popup.css"/>
    <link rel="stylesheet" href="../../asset/css/animate.css"/>

    <!-- Main Stylesheets -->
    <link rel="stylesheet" href="../../asset/css/style.css"/>


    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header section -->
    <header class="header-section">
        <div class="header-warp">
            
            <div class="header-bar-warp d-flex">
                <!-- site logo -->
                <a href="/" class="site-logo">
                    <img src="../../asset/img/logo.png" alt="">
                </a>
                <nav class="top-nav-area w-100">
                    <div class="user-panel">
                        <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                    <ul class="main-menu primary-menu" style="position: relative; padding-left: 60px; ">
                        <img src="../../uploads/avatars<?php echo e(Auth::user()->avatar); ?>" style="width: 35px; height: 35px; position: absolute; ; left: 10px; border-radius: 50%;">
                        <li><a><?php echo e(Auth::user()->name); ?></a>
                        <ul class="sub-menu">
                        <li><a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                            Logout
                        </a>
                        <li><a href="<?php echo e(url('/profile')); ?>">Profil</a></li>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                        </li>
                        </ul>
                        </li> 
                    </ul>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Masuk</a> / <a href="<?php echo e(url('/register')); ?>">Daftar</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
                    </div>
                    <!-- Menu -->
                    <ul class="main-menu primary-menu">
                        <li><a href="/">Home</a></li>
                        <li><a href="<?php echo e(url('/login')); ?>">Rakitan</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(url('/login')); ?>">Buat Rakitan Baru</a></li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(url('/review')); ?>">Informasi</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(url('/review')); ?>">Game Terbaru</a></li>
                            </ul>
                        </li>
                        <?php if(Route::has('login')): ?>
                        <?php if(Auth::check()  && Auth::user()->isAdmin()): ?>
                        <li><a href="<?php echo e(url('/posting')); ?>">Konten</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(url('/posting')); ?>">Tambah Konten</a></li>
                            </ul>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>
                        <li><a href="<?php echo e(url('/about')); ?>">Tentang</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(url('/about')); ?>">Kontak</a></li>
                                <li><a href="<?php echo e(url('/spek')); ?>">Spesifikasi Sistem</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header section end -->

    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="/../../asset/img/page-top-bg/1.jpg">
        <div class="page-info">
            <h2>Games Terbaru</h2>
            <div class="site-breadcrumb">
                <a href="">Informasi</a>  /
                <span>Games Terbaru</span>
            </div>
        </div>
    </section>
    <!-- Page top end-->
    


    <?php echo $__env->yieldContent('content'); ?>


            <!-- Footer section -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-left-pic">
                <img src="../../asset/img/footer-left-pic.png" alt="">
            </div>
            <div class="footer-right-pic">
                <img src="../../asset/img/footer-right-pic.png" alt="">
            </div>
            <a href="#" class="footer-logo">
                <img src="../../asset/img/logo.png" alt="">
            </a>
            <ul class="main-menu footer-menu">
                <li><a href="/">Home</a></li>
                <li><a href="">Rakitan</a></li>
                <li><a href="<?php echo e(url('/review')); ?>">Informasi</a></li>
                <li><a href="<?php echo e(url('/about')); ?>">Tentang</a></li>
            </ul>
            <div class="footer-social d-flex justify-content-center">
                <a href="#"><i class="fa fa-pinterest"></i></a>
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-dribbble"></i></a>
                <a href="#"><i class="fa fa-behance"></i></a>
            </div>
            <div class="copyright"><a href="">maulana020716</a> 2019 @ All rights reserved</div>
        </div>
    </footer>
    <!-- Footer section end -->


    <!--====== Javascripts & Jquery ======-->
    <script src="../../asset/js/jquery-3.2.1.min.js"></script>
    <script src="../../asset/js/bootstrap.min.js"></script>
    <script src="../../asset/js/jquery.slicknav.min.js"></script>
    <script src="../../asset/js/owl.carousel.min.js"></script>
    <script src="../../asset/js/jquery.sticky-sidebar.min.js"></script>
    <script src="../../asset/js/jquery.magnific-popup.min.js"></script>
    <script src="../../asset/js/main.js"></script>

    </body>
</html>